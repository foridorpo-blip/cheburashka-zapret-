@echo off
chcp 65001 > nul
cd /d "%~dp0"

REM Стратегия: МАКСИМАЛЬНАЯ АГРЕССИВНОСТЬ (Все сайты)
REM Для очень строгих фильтров - более ресурсоёмко

set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
cd /d %BIN%

start "zapret: AGGRESSIVE" /min "%BIN%winws.exe" ^
--wf-tcp=80,443,2053,2083,2087,2096,8443 ^
--wf-udp=443,19294-19344,50000-50100 ^
--filter-udp=443 ^
--ipset="%LISTS%ipset-all.txt" ^
--hostlist="%LISTS%list-general.txt" ^
--hostlist="%LISTS%list-general-user.txt" ^
--hostlist-exclude="%LISTS%list-exclude.txt" ^
--hostlist-exclude="%LISTS%list-exclude-user.txt" ^
--ipset-exclude="%LISTS%ipset-exclude.txt" ^
--ipset-exclude="%LISTS%ipset-exclude-user.txt" ^
--dpi-desync=fake ^
--dpi-desync-repeats=8 ^
--dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" ^
--new ^
--filter-udp=19294-19344 ^
--filter-l7=discord,stun ^
--dpi-desync=fake ^
--dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" ^
--dpi-desync-fake-stun="%BIN%ACTIVE_DISCORD_UDP.bin" ^
--dpi-desync-repeats=8 ^
--new ^
--filter-tcp=443 ^
--hostlist="%LISTS%list-general.txt" ^
--ip-id=zero ^
--dpi-desync=fake,hostfakesplit ^
--dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com ^
--dpi-desync-hostfakesplit-mod=host=www.google.com,altorder=1 ^
--dpi-desync-fooling=ts
