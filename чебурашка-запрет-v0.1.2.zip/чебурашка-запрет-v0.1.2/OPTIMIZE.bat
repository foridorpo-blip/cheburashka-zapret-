@echo off
chcp 65001 > nul
cd /d "%~dp0"

REM Стратегия: СРЕДНЯЯ АГРЕССИВНОСТЬ (Optimized для YouTube + Discord)
REM Идеально для повседневного использования

set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
cd /d %BIN%

start "zapret: OPTIMIZE" /min "%BIN%winws.exe" ^
--wf-tcp=80,443,2053,2083,2087,2096,8443 ^
--wf-udp=443,19294-19344,50000-50100 ^
--filter-udp=443 ^
--hostlist="%LISTS%list-general.txt" ^
--hostlist="%LISTS%list-general-user.txt" ^
--hostlist-exclude="%LISTS%list-exclude.txt" ^
--hostlist-exclude="%LISTS%list-exclude-user.txt" ^
--dpi-desync=fake ^
--dpi-desync-repeats=5 ^
--dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" ^
--new ^
--filter-udp=19294-19344 ^
--filter-l7=discord ^
--dpi-desync=fake ^
--dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" ^
--dpi-desync-repeats=5 ^
--new ^
--filter-tcp=443 ^
--hostlist="%LISTS%list-general.txt" ^
--dpi-desync=fake,hostfakesplit ^
--dpi-desync-fake-tls-mod=rnd,dupsid,sni=ya.ru ^
--dpi-desync-hostfakesplit-mod=host=ya.ru,altorder=1
