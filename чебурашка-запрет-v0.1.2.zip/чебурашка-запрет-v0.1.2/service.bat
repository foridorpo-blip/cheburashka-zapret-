@echo off
setlocal EnableDelayedExpansion
chcp 65001 > nul
set "LOCAL_VERSION=Cheburashka v0.1.2 ENHANCED"
set "BUILD_DATE=06.09.2026"

:: Логирование
set "LOG_FILE=%~dp0logs\cheburashka_%date:~6,4%-%date:~3,2%-%date:~0,2%_%time:~0,2%-%time:~3,2%-%time:~6,2%.log"

:: Внешние команды для управления из других скриптов
if "%~1"=="status_zapret" (
    call :test_service CheburashkaZapretService soft
    call :tcp_enable
    exit /b
)

if "%~1"=="check_updates" (
    if defined NO_UPDATE_CHECK exit /b
    if exist "%~dp0utils\check_updates.enabled" (
        if not "%~2"=="soft" (
            start /b service check_updates soft
        ) else (
            call :service_check_updates soft
        )
    )
    exit /b
)

if "%~1"=="load_game_filter" (
    call :game_switch_status
    exit /b
)

if "%~1"=="load_user_lists" (
    call :load_user_lists
    exit /b
)

:: Проверка прав администратора при запуске
if "%1"=="admin" (
    call :check_command chcp
    call :check_command find
    call :check_command findstr
    call :check_command netsh
    call :load_user_lists
    call :log_action "Менеджер запущен с правами Администратора"
    echo [УСПЕХ] Менеджер запущен с правами Администратора.
) else (
    call :check_extracted
    call :check_command powershell
    echo [СТАТУС] Запрос прав администратора...
    call :log_action "Запрос UAC прав администратора"
    powershell -NoProfile -Command "Start-Process 'cmd.exe' -ArgumentList '/c \"\"%~f0\" admin\"' -Verb RunAs"
    exit /b
)

:: ГЛАВНОЕ ИНТЕРАКТИВНОЕ МЕНЮ ================================
title ЧЕБУРАШКА МЕНЕДЖЕР СЛУЖБЫ [!LOCAL_VERSION!]

:menu
cls
chcp 65001 > nul

set "GameFilterStatus=ВЫКЛ"
set "IPsetStatus=ВЫКЛ"
set "CheckUpdatesStatus=ВЫКЛ"
set "CurrentStrategy=Текущая стратегия: По умолчанию (split2 + Discord UDP)"

echo.
echo   ═══════════════════════════════════════════════════════════
echo     ЧЕБУРАШКА МЕНЕДЖЕР СЛУЖБЫ [!LOCAL_VERSION!]
echo   ═══════════════════════════════════════════════════════════
echo.  !CurrentStrategy!
echo   ───────────────────────────────────────────────────────────
echo.
echo   :: УПРАВЛЕНИЕ СЕРВЕРОМ СЛУЖБЫ
echo      1. Установить службу (Автозапуск при старте Windows)
echo      2. Полностью удалить службу из системы
echo      3. Проверить текущий статус работы
echo      4. Быстрая очистка (остановить всё)
echo      5. Перезагрузить службу (Restart)
echo.
echo   :: НАСТРОЙКИ ФИЛЬТРАЦИИ ТРАФИКА
echo      6. Игровой фильтр (Game Filter)     [!GameFilterStatus!]
echo      7. IPSet Фильтрация                [!IPsetStatus!]
echo      8. Авто-проверка обновлений         [!CheckUpdatesStatus!]
echo      9. Заменить активные фейки (Replace fakes)
echo.
echo   :: ОБНОВЛЕНИЯ И СПИСКИ САНКЦИОННЫХ САЙТОВ
echo      10. Обновить списки IPSet
echo      11. Обновить файлы Hosts
echo      12. Проверить наличие обновлений Чебурашки
echo.
echo   :: ДИАГНОСТИКА И ЛОГИРОВАНИЕ
echo      13. Запустить полную диагностику конфликтов
echo      14. Запустить экспресс-тесты обхода DPI
echo      15. Просмотр логов системы
echo      16. Резервное копирование конфигурации
echo      17. Восстановить конфигурацию из бэкапа
echo.
echo   ───────────────────────────────────────────────────────────
echo      0. Выход из менеджера
echo.

set "menu_choice=null"
set /p menu_choice=   Выберите пункт меню (0-17): 

if "%menu_choice%"=="1" goto service_install
if "%menu_choice%"=="2" goto service_remove
if "%menu_choice%"=="3" goto service_status
if "%menu_choice%"=="4" goto batch_cleanup
if "%menu_choice%"=="5" goto service_restart
if "%menu_choice%"=="6" goto game_switch
if "%menu_choice%"=="7" goto ipset_switch
if "%menu_choice%"=="8" goto check_updates_switch
if "%menu_choice%"=="9" goto replace_active_fakes
if "%menu_choice%"=="10" goto ipset_update
if "%menu_choice%"=="11" goto hosts_update
if "%menu_choice%"=="12" goto service_check_updates
if "%menu_choice%"=="13" goto service_diagnostics
if "%menu_choice%"=="14" goto run_tests
if "%menu_choice%"=="15" goto view_logs
if "%menu_choice%"=="16" goto backup_config
if "%menu_choice%"=="17" goto restore_config
if "%menu_choice%"=="0" (
    call :log_action "Менеджер закрыт пользователем"
    exit /b
)
goto menu


:: ФУНКЦИЯ ЛОГИРОВАНИЯ ====================================
:log_action
if not exist "%~dp0logs" mkdir "%~dp0logs"
for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set mydate=%%c-%%a-%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set mytime=%%a:%%b)
echo [%mydate% %mytime%] %~1 >> "%LOG_FILE%"
exit /b


:: ФУНКЦИЯ ЗАГРУЗКИ БАЗЫ САЙТОВ ==========================
:load_user_lists
set "LISTS_PATH=%~dp0lists\"

if not exist "%LISTS_PATH%" mkdir "%LISTS_PATH%"

if not exist "%LISTS_PATH%list-general.txt" (
    (
        echo youtube.com
        echo ://youtube.com
        echo youtu.be
        echo googlevideo.com
        echo *.googlevideo.com
        echo ytimg.com
        echo discord.com
        echo ://discord.com
        echo discord.gg
        echo *.discord.media
        echo discordapp.com
        echo discordapp.net
        echo gateway.discord.gg
    ) > "%LISTS_PATH%list-general.txt"
)

if not exist "%LISTS_PATH%ipset-exclude-user.txt" (
    echo 203.0.113.113/32>"%LISTS_PATH%ipset-exclude-user.txt"
)
if not exist "%LISTS_PATH%list-general-user.txt" (
    echo # Сюда можно добавлять свои кастомные сайты построчно>"%LISTS_PATH%list-general-user.txt"
    echo domain.example.abc>>"%LISTS_PATH%list-general-user.txt"
)
if not exist "%LISTS_PATH%list-exclude-user.txt" (
    echo domain.example.abc>"%LISTS_PATH%list-exclude-user.txt"
)
exit /b


:: ВКЛЮЧЕНИЕ ТАЙМШТАМПОВ СЕТИ TCP ==========================
:tcp_enable
chcp 437 > nul
netsh interface tcp show global | findstr /i "timestamps" | findstr /i "enabled" > nul || netsh interface tcp set global timestamps=enabled > nul 2>&1
exit /b


:: БЫСТРАЯ ОЧИСТКА ========================================
:batch_cleanup
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   БЫСТРАЯ ОЧИСТКА И ОСТАНОВКА
echo ═══════════════════════════════════════════════════════════
echo.
call :log_action "Инициирована быстрая очистка системы"

echo [СТАТУС] Останавливаю текущую службу...
net stop CheburashkaZapretService >nul 2>&1

echo [СТАТУС] Завершаю процесс перехвата DPI (winws.exe)...
taskkill /IM winws.exe /F > nul 2>&1

echo [СТАТУС] Удаляю временные соединения...
netsh winsock reset catalog >nul 2>&1

echo.
echo [✓ УСПЕХ] Система полностью очищена
call :log_action "Быстрая очистка завершена"
echo.
pause
goto menu


:: ПЕРЕЗАГРУЗКА СЛУЖБЫ ====================================
:service_restart
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   ПЕРЕЗАГРУЗКА СЛУЖБЫ
echo ═══════════════════════════════════════════════════════════
echo.
call :log_action "Инициирована перезагрузка службы"

echo [СТАТУС] Останавливаю службу...
net stop CheburashkaZapretService >nul 2>&1
timeout /t 2 /nobreak

echo [СТАТУС] Запускаю службу...
net start CheburashkaZapretService >nul 2>&1
timeout /t 2 /nobreak

echo [✓ УСПЕХ] Служба перезагружена
call :log_action "Служба успешно перезагружена"
echo.
pause
goto menu


:: ПРОВЕРКА СТАТУСА РАБОТЫ СЛУЖБЫ ========================
:service_status
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   СТАТУС СЛУЖБЫ ЧЕБУРАШКА-ЗАПРЕТ
echo ═══════════════════════════════════════════════════════════
echo.

chcp 437 > nul
sc query "CheburashkaZapretService" >nul 2>&1
if !errorlevel!==0 (
    for /f "tokens=2*" %%A in ('reg query "HKLM\System\CurrentControlSet\Services\CheburashkaZapretService" /v DisplayName 2^>nul') do (
        chcp 65001 > nul
        echo Служба установлена в системе как: "%%B"
    )
)

call :test_service CheburashkaZapretService
call :test_service WinDivert

set "BIN_PATH=%~dp0bin\"
chcp 65001 > nul
if not exist "%BIN_PATH%WinDivert64.sys" (
    echo [⚠ ОШИБКА] Низкоуровневый драйвер WinDivert64.sys НЕ НАЙДЕН в папке bin!
) else (
    echo [✓] Драйвер WinDivert64.sys найден
)

if not exist "%BIN_PATH%winws.exe" (
    echo [⚠ ОШИБКА] Исполняемый файл winws.exe НЕ НАЙДЕН в папке bin!
) else (
    echo [✓] Исполняемый файл winws.exe найден
)

tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if !errorlevel!==0 (
    echo [✓ АКТИВЕН] Процесс перехвата DPI (winws.exe) РАБОТАЕТ
) else (
    echo [✗ ОСТАНОВЛЕН] Процесс перехвата DPI (winws.exe) не запущен
)

echo.
echo [ИНФОРМАЦИЯ] Последнее действие записано в логи:
echo   %LOG_FILE%
echo.
pause
goto menu

:test_service
set "ServiceName=%~1"
set "ServiceStatus="

for /f "tokens=3 delims=: " %%A in ('sc query "%ServiceName%" ^| findstr /i "STATE"') do set "ServiceStatus=%%A"
set "ServiceStatus=%ServiceStatus: =%"

chcp 65001 > nul
if "%ServiceStatus%"=="RUNNING" (
    if "%~2"=="soft" (
        echo Служба "%ServiceName%" уже запущена в фоне. Используйте пункт 5 (Перезагрузить) для рестарта.
    ) else (
        echo [✓] Компонент "%ServiceName%" успешно СЛУЖИТ в системе (Статус: RUNNING).
    )
) else if "%ServiceStatus%"=="STOP_PENDING" (
    echo [⚠ ВНИМАНИЕ] Компонент %ServiceName% завис в состоянии остановки!
) else if not "%~2"=="soft" (
    echo [✗] Компонент "%ServiceName%" в системе НЕ запущен.
)
exit /b


:: ПОЛНОЕ УДАЛЕНИЕ СЛУЖБЫ ==================================
:service_remove
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   ПОЛНОЕ УДАЛЕНИЕ СЛУЖБЫ
echo ═══════════════════════════════════════════════════════════
echo.
call :log_action "Инициировано удаление службы"

set "SRVCNAME=CheburashkaZapretService"
sc query "!SRVCNAME!" >nul 2>&1
if !errorlevel!==0 (
    echo [СТАТУС] Останавливаю фоновую службу %SRVCNAME%...
    net stop %SRVCNAME% >nul 2>&1
    timeout /t 1 /nobreak
    echo [СТАТУС] Удаляю службу из реестра Windows...
    sc delete %SRVCNAME%
) else (
    echo [ИНФОРМАЦИЯ] Служба "%SRVCNAME%" не была установлена в системе.
)

echo [СТАТУС] Завершаю процессы winws.exe...
tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if !errorlevel!==0 (
    taskkill /IM winws.exe /F > nul
    echo [✓] Все процессы winws.exe завершены
)

echo [СТАТУС] Очищаю драйверы WinDivert...
net stop "WinDivert" >nul 2>&1
sc delete "WinDivert" >nul 2>&1
net stop "WinDivert14" >nul 2>&1
sc delete "WinDivert14" >nul 2>&1

echo.
echo [✓ УСПЕХ] Все компоненты Чебурашки полностью вычищены из системы.
call :log_action "Служба полностью удалена из системы"
echo.
pause
goto menu


:: ПРОСМОТР ЛОГОВ ==========================================
:view_logs
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   ПРОСМОТР ЛОГОВ СИСТЕМЫ
echo ═══════════════════════════════════════════════════════════
echo.

set "LOGS_DIR=%~dp0logs"
if not exist "%LOGS_DIR%" (
    echo [ИНФОРМАЦИЯ] Папка логов ещё не создана
    pause
    goto menu
)

echo [ПОСЛЕДНИЕ 30 ЗАПИСЕЙ ЛОГОВ]
echo.
for /f "skip=30 tokens=*" %%A in ('dir /b /o-d "%LOGS_DIR%\*.log" ^| findstr /v "^$"') do (
    set "LATEST_LOG=%%A"
)

if defined LATEST_LOG (
    type "%LOGS_DIR%\%LATEST_LOG%" | find /v "" | (
        set /a count=0
        for /f "tokens=*" %%A in ('findstr ".*"') do (
            set /a count+=1
            if !count! geq 1 echo %%A
        )
    )
) else (
    echo [ИНФОРМАЦИЯ] Нет записей логов
)

echo.
pause
goto menu


:: РЕЗЕРВНОЕ КОПИРОВАНИЕ КОНФИГУРАЦИИ ====================
:backup_config
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   РЕЗЕРВНОЕ КОПИРОВАНИЕ КОНФИГУРАЦИИ
echo ═══════════════════════════════════════════════════════════
echo.

set "BACKUP_DIR=%~dp0backups"
set "LISTS_DIR=%~dp0lists"
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"

for /f "tokens=2-4 delims=/ " %%a in ('date /t') do (set backup_date=%%c-%%a-%%b)
for /f "tokens=1-2 delims=/:" %%a in ('time /t') do (set backup_time=%%a-%%b)
set "BACKUP_NAME=backup_%backup_date%_%backup_time%"

echo [СТАТУС] Копирую файлы конфигурации...
xcopy "%LISTS_DIR%\*.txt" "%BACKUP_DIR%\%BACKUP_NAME%\" /E /I /Y >nul 2>&1

echo [✓ УСПЕХ] Конфигурация сохранена в:
echo   %BACKUP_DIR%\%BACKUP_NAME%\
call :log_action "Конфигурация скопирована в бэкап: %BACKUP_NAME%"
echo.
pause
goto menu


:: ВОССТАНОВЛЕНИЕ КОНФИГУРАЦИИ ===========================
:restore_config
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   ВОССТАНОВЛЕНИЕ КОНФИГУРАЦИИ ИЗ БЭКАПА
echo ═══════════════════════════════════════════════════════════
echo.

set "BACKUP_DIR=%~dp0backups"
if not exist "%BACKUP_DIR%" (
    echo [ОШИБКА] Папка бэкапов не найдена!
    pause
    goto menu
)

echo Доступные бэкапы:
set "count=0"
for /d %%F in ("%BACKUP_DIR%\backup_*") do (
    set /a count+=1
    echo   !count!. %%~nF
    set "backup!count!=%%F"
)

if "%count%"=="0" (
    echo [ОШИБКА] Нет доступных бэкапов
    pause
    goto menu
)

echo   0. Отмена
echo.
set "choice="
set /p "choice=Выберите номер бэкапа для восстановления: "
if "%choice%"=="0" goto menu

set "selected_backup=!backup%choice%!"
if not defined selected_backup (
    echo [ОШИБКА] Неверный выбор
    pause
    goto restore_config
)

set "LISTS_DIR=%~dp0lists"
echo [СТАТУС] Восстанавливаю конфигурацию...
xcopy "%selected_backup%\*" "%LISTS_DIR%\" /E /I /Y >nul 2>&1

echo [✓ УСПЕХ] Конфигурация восстановлена из бэкапа
call :log_action "Конфигурация восстановлена из: %selected_backup%"
echo.
pause
goto menu


:: УСТАНОВКА СЛУЖБЫ =======================================
:service_install
cls
chcp 65001 > nul
echo ═══════════════════════════════════════════════════════════
echo   УСТАНОВКА НОВОГО СЕРВЕРА СЛУЖБЫ
echo ═══════════════════════════════════════════════════════════
echo.
call :log_action "Инициирована установка новой службы"

cd /d "%~dp0"
set "BIN_PATH=%~dp0bin\"
set "LISTS_PATH=%~dp0lists\"
set "SRVCNAME=CheburashkaZapretService"
set "DISPLAY_NAME=Чебурашка-Запрет DPI Service v0.1.2"

:: Предварительная очистка перед установкой нового сервера
echo [СТАТУС] Очищаю предыдущую конфигурацию...
sc stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
taskkill /f /im winws.exe >nul 2>&1

echo [✓] Старая конфигурация удалена
echo [СТАТУС] Регистрирую новую службу "%DISPLAY_NAME%"...

sc create %SRVCNAME% binPath= "%BIN_PATH%winws.exe" DisplayName= "%DISPLAY_NAME%"
sc config %SRVCNAME% start= auto
sc start %SRVCNAME%

echo [✓ УСПЕХ] Служба успешно установлена и запущена
call :log_action "Служба успешно установлена и запущена"
echo.
pause
goto menu


:: ЗАГЛУШКИ ДЛЯ ОСТАЛЬНЫХ ФУНКЦИЙ ========================
:game_switch
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:ipset_switch
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:check_updates_switch
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:replace_active_fakes
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:ipset_update
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:hosts_update
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:service_check_updates
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:service_diagnostics
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:run_tests
echo [ФУНКЦИЯ В РАЗРАБОТКЕ]
pause
goto menu

:check_extracted
exit /b
