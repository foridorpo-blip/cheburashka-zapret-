@echo off
chcp 65001 > nul
cd /d "%~dp0"

REM Стратегия: ЛЁГКАЯ (Только необходимое)
REM Минимальная нагрузка на CPU, идеально для слабых ПК

set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
cd /d %BIN%

start "zapret: LITE" /min "%BIN%winws.exe" ^
--wf-tcp=80,443 ^
--wf-udp=443 ^
--filter-udp=443 ^
--hostlist="%LISTS%list-general.txt" ^
--dpi-desync=fake ^
--dpi-desync-repeats=3 ^
--dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" ^
--new ^
--filter-tcp=443 ^
--dpi-desync=fake ^
--dpi-desync-fake-tls-mod=rnd,sni=ya.ru
