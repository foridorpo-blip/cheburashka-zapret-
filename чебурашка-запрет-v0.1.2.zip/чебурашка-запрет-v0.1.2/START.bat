@echo off
setlocal EnableDelayedExpansion

REM Проверяем права администратора
net session >nul 2>&1
if errorlevel 1 (
    echo [!]Требуются права администратора!
    echo    Перезапуск с повышенными привилегиями...
    timeout /t 1 >nul
    powershell -NoProfile -Command "Start-Process cmd -ArgumentList '/c %~s0' -Verb RunAs" >nul 2>&1
    exit /b
)

chcp 65001 > nul 2>&1
cd /d "%~dp0"

title ЧЕБУРАШКА МЕНЕДЖЕР - Выбор стратегии
cls

echo.
echo   ═══════════════════════════════════════════════════════════
echo     ЧЕБУРАШКА-ЗАПРЕТ v0.1.2 - ВЫБОР СТРАТЕГИИ ЗАПУСКА
echo   ═══════════════════════════════════════════════════════════
echo.
echo   ДОСТУПНЫЕ СТРАТЕГИИ:
echo.
echo      1. MENU       - Запустить менеджер служб (интерактивное меню)
echo      2. OPTIMIZE   - Оптимальная (YouTube + Discord) - РЕКОМЕНДУЕТСЯ
echo      3. LITE       - Лёгкая (для слабых ПК)
echo      4. AGGRESSIVE - Максимально жёсткая (все сайты)
echo      5. GAMING     - Для игр (Steam, Epic, Valorant)
echo.
echo      0. Выход
echo.

:choice_loop
set "choice="
set /p "choice=Выберите стратегию (0-5): "

if "!choice!"=="0" (
    cls
    echo Выход...
    timeout /t 1 >nul
    exit /b 0
)

if "!choice!"=="1" (
    if exist "service.bat" (
        call "service.bat" admin
        exit /b 0
    ) else (
        echo [!] ОШИБКА: service.bat не найден!
        timeout /t 2 >nul
        cls
        goto choice_loop
    )
)

if "!choice!"=="2" (
    if exist "OPTIMIZE.bat" (
        call "OPTIMIZE.bat"
        exit /b 0
    ) else (
        echo [!] ОШИБКА: OPTIMIZE.bat не найден!
        timeout /t 2 >nul
        cls
        goto choice_loop
    )
)

if "!choice!"=="3" (
    if exist "LITE.bat" (
        call "LITE.bat"
        exit /b 0
    ) else (
        echo [!] ОШИБКА: LITE.bat не найден!
        timeout /t 2 >nul
        cls
        goto choice_loop
    )
)

if "!choice!"=="4" (
    if exist "AGGRESSIVE.bat" (
        call "AGGRESSIVE.bat"
        exit /b 0
    ) else (
        echo [!] ОШИБКА: AGGRESSIVE.bat не найден!
        timeout /t 2 >nul
        cls
        goto choice_loop
    )
)

if "!choice!"=="5" (
    if exist "GAMING.bat" (
        call "GAMING.bat"
        exit /b 0
    ) else (
        echo [!] ОШИБКА: GAMING.bat не найден!
        timeout /t 2 >nul
        cls
        goto choice_loop
    )
)

echo.
echo [!] ОШИБКА: Неверный выбор. Введите число от 0 до 5.
timeout /t 2 >nul
cls
goto choice_loop
