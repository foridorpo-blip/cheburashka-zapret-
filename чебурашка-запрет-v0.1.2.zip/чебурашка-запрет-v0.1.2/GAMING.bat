@echo off
chcp 65001 > nul
cd /d "%~dp0"

REM Стратегия: ДЛЯ ИГР (Gaming optimized)
REM Специально для Steam, Epic, Valorant и других игровых платформ

set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
cd /d %BIN%

start "zapret: GAMING" /min "%BIN%winws.exe" ^
--wf-tcp=80,443,2053,2083,2087,2096,8443,27015-27030,3074 ^
--wf-udp=443,19294-19344,50000-50100,27015-27030,3074 ^
--filter-udp=443 ^
--hostlist="%LISTS%list-general.txt" ^
--hostlist="%LISTS%list-general-user.txt" ^
--dpi-desync=fake ^
--dpi-desync-repeats=4 ^
--dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" ^
--new ^
--filter-tcp=80,443 ^
--hostlist="%LISTS%list-general.txt" ^
--dpi-desync=fake,hostfakesplit ^
--dpi-desync-fake-tls-mod=rnd,dupsid,sni=ya.ru ^
--dpi-desync-hostfakesplit-mod=host=ya.ru,altorder=1 ^
--new ^
--filter-tcp=27015-27030,3074 ^
--dpi-desync=fake ^
--dpi-desync-any-protocol=1 ^
--dpi-desync-fake-http="%BIN%tls_clienthello_www_google_com.bin"
